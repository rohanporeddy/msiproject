#include <iostream>
#include <stdio.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

//created 2 structures for cache block and block memory
struct Cache_block{
	int _processor_cache_block[4] = {0};
	int state = -1;
	char cache_location;
	
};

struct Block_memory{
	int _memory_block[4];
	char block_location;
};


struct Cache_block p1, p2, p3, p4;
struct Block_memory b;


void readProcessor(int _processorId, int location){
	//mapping with the processors
	switch(_processorId){
		case 1:
			
			//checking other processors states weather it is in MODIFIED STATE
				if(p2.state == 1 || p2.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p2.state = -1;	
				}
				if(p3.state == 1 || p3.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p4.state == 1 || p4.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
			
			
			//first it checks the state of processor
			if(p1.state == -1 && p1._processor_cache_block[location] == 0){
				
				//copy values from block memory --> p1 cache block
				for(int i = 0 ; i < 4; i++){
					p1._processor_cache_block[i] = b._memory_block[i];
				}
				p1.state = 0; //changed the state to SHARED;
				printf("p1 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p1._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np1 state :SHARED\n");	
		
			}
			else if((p1.state == 0 || p1.state == 1) && p1._processor_cache_block[location] != 0){ 
			
				//display the values from the cache memory
				printf("p1 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p1._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np1 state :SHARED\n");
			
			}
		
			if(p2.state == -1 ) printf("p2 state : INVALID\n");
			else if(p2.state == 0) printf("p2 state : SHARED\n");
			else if (p2.state == 1) printf("p2 state : MODIFIED\n");
			
			if(p3.state == -1 ) printf("p3 state : INVALID\n");
			else if(p3.state == 0) printf("p3 state : SHARED\n");
			else if (p3.state == 1) printf("p3 state : MODIFIED\n");
			
			if(p4.state == -1 ) printf("p4 state : INVALID\n");
			else if(p4.state == 0) printf("p4 state : SHARED\n");
			else if (p4.state == 1) printf("p4 state : MODIFIED\n");
			
			break;
		
		case 2:
				if(p1.state == 1 || p1.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				p1.state = -1;	
				}
				if(p3.state == 1 || p3.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p4.state == 1 || p4.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
			
			
				//first it checks the state of processor
			if(p2.state == -1 && p2._processor_cache_block[location] == 0){
				//It generates ReadMiss the bus operation
				printf("\np2 state : INVALID. It generates ReadMiss to bus operation\n");
				
				//copy values from block memory --> p2 cache block
				for(int i = 0 ; i < 4; i++){
					p2._processor_cache_block[i] = b._memory_block[i];
				}
				
				p2.state = 0; //changed the state to SHARED;
				printf("p2 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p2._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np2 state :SHARED\n");
			
					
			}
			else if((p2.state == 0 || p2.state == 1) && p2._processor_cache_block[location] != 0){ 
			
				//display the values from the cache memory
				printf("p2 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p2._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np2 state :SHARED\n");	
			} 
			
			if(p1.state == -1 ) printf("p1 state : INVALID\n");
			else if(p1.state == 0) printf("p1 state : SHARED\n");
			else if (p1.state == 1) printf("p1 state : MODIFIED\n");
			
			if(p3.state == -1 ) printf("p3 state : INVALID\n");
			else if(p3.state == 0) printf("p3 state : SHARED\n");
			else if (p3.state = 1) printf("p3 state : MODIFIED\n");
				
			if(p4.state == -1 ) printf("p4 state : INVALID\n");
			else if(p4.state == 0) printf("p4 state : SHARED\n");
			else if (p4.state == 1) printf("p4 state : MODIFIED\n");
			break;
			
		case 3:
			
				if(p2.state == 1 || p2.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p2.state = -1;	
				}
				if(p1.state == 1 || p1.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				p1.state = -1;
				}
				if(p4.state == 1 || p4.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
			
				//first it checks the state of processor
			if(p3.state == -1 && p3._processor_cache_block[location] == 0){
				//It generates ReadMiss the bus operation
				printf("\np3 state : INVALID. It generates ReadMiss to bus operation\n");
				
				//copy values from block memory --> p3 cache block
				for(int i = 0 ; i < 4; i++){
					p3._processor_cache_block[i] = b._memory_block[i];
				}
				
				p3.state = 0; //changed the state to SHARED;
				printf("p3 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p3._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np3 state :SHARED\n");
				
			}
			else if((p3.state == 0 || p3.state == 1) && p3._processor_cache_block[location] != 0){  
				//display the values from the cache memory
				printf("p3 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p3._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np3 state :SHARED\n");	
			}
			
			if(p1.state == -1 ) printf("p1 state : INVALID\n");
			else if(p1.state == 0) printf("p1 state : SHARED\n");
			else if (p1.state == 1) printf("p1 state : MODIFIED\n");
			
			if(p2.state == -1 ) printf("p2 state : INVALID\n");
			else if(p2.state == 0) printf("p2 state : SHARED\n");
			else if (p2.state == 1) printf("p2 state : MODIFIED\n");
				
			if(p4.state == -1 ) printf("p4 state : INVALID\n");
			else if(p4.state == 0) printf("p4 state : SHARED\n");
			else if (p4.state == 1) printf("p4 state : MODIFIED\n");
			break;
			
		case 4:
			
				if(p2.state == 1 || p2.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p2.state = -1;	
				}
				if(p3.state == 1 || p3.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p1.state == 1 || p1.state == 0){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				}
				//first it checks the state of processor
			if(p4.state == -1 && p4._processor_cache_block[location] == 0){
				//It generates ReadMiss the bus operation
				printf("\np4 state : INVALID. It generates ReadMiss to bus operation\n");
				
				//copy values from block memory --> p4 cache block
				for(int i = 0 ; i < 4; i++){
					p4._processor_cache_block[i] = b._memory_block[i];
				}

				p4.state = 0; //changed the state to SHARED;
				printf("p4 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p4._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np4 state :SHARED\n");
				
			}
			else if((p4.state == 0 || p4.state == 1) && p4._processor_cache_block[location] != 0){ 
				
				//display the values from the cache memory
				printf("p4 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p4._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np4 state :SHARED\n");			
			}
			
			if(p1.state == -1 ) printf("p1 state : INVALID\n");
			else if(p1.state == 0) printf("p1 state : SHARED\n");
			else if (p1.state == 1) printf("p1 state : MODIFIED\n");
			
			if(p3.state == -1 ) printf("p3 state : INVALID\n");
			else if(p3.state == 0) printf("p3 state : SHARED\n");
			else if (p3.state == 1) printf("p3 state : MODIFIED\n");
				
			if(p2.state == -1 ) printf("p2 state : INVALID\n");
			else if(p2.state == 0) printf("p2 state : SHARED\n");
			else if (p2.state == 1) printf("p2 state : MODIFIED\n"); 
	 		break;
	 		
	}
	return;
}

void writeProcessor(int _processorId, int location, int _memory_location_value){
	//mapping with processors and block_memory
	switch(_processorId){
		case 1:
			if(p1.state == -1 && p1._processor_cache_block[location] == 0){ //status INVALID and cache memory location is zero
				
				//checking other processors states weather it is in SHARED STATE
				if(p2.state == 0 || p2.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p2.state = -1;	
				}
				if(p3.state == 0 || p3.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p4.state == 0 || p4.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
			
				
				//It generates WriteMiss on the bus operation
				printf("\np1 state : INVALID. It generates WriteMiss to bus operation\n");
				
				//copy values from block memory --> p1 cache block
				for(int i = 0 ; i < 4; i++){
					p1._processor_cache_block[i] = b._memory_block[i];
				}
				
				//write the _memory_location_value in the location of cache Memory
					p1._processor_cache_block[location] = _memory_location_value;
					
				p1.state = 1; //changed the state to MODIFIED;
				printf("p1 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p1._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np1 state :MODIFIED\n");
				
			}
			
			else if(p1.state = 1 && p1._processor_cache_block[location] != 0){   //status is MODIFIED, not need to copy values from memory block, replace the user_value to cache block
			
				//checking other processors states weather it is in MODIFIED STATE
				if(p2.state == 0 || p2.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p2.state = -1;
				}
				if(p3.state == 0 || p3.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p4.state == 0 || p4.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
			
				//p1 writes specific location value			
				p1._processor_cache_block[location] = _memory_location_value;
					
				p1.state = 1; //changed the state to MODIFIED;
				printf("p1 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p1._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np1 state :MODIFIED\n");
			
			
			}
			
			if(p2.state == -1 ) printf("p2 state : INVALID\n");
			else if(p2.state == 0) printf("p2 state : SHARED\n");
			else if (p2.state == 1) printf("p2 state : MODIFIED\n");
			
			if(p3.state == -1 ) printf("p3 state : INVALID\n");
			else if(p3.state == 0) printf("p3 state : SHARED\n");
			else if (p3.state == 1) printf("p3 state : MODIFIED\n");
				
			if(p4.state == -1 ) printf("p4 state : INVALID\n");
			else if(p4.state == 0) printf("p4 state : SHARED\n");
			else if (p4.state == 1) printf("p4 state : MODIFIED\n"); 
			break;
			
		case 2:
			if(p2.state == -1 && p2._processor_cache_block[location] == 0){ //status INVALID and cache memory location is zero
				
				//checking other processors states weather it is in MODIFIED STATE
				if(p1.state == 0 || p1.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				p1.state = -1;

				}
				if(p3.state == 0 || p3.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p4.state == 0 || p4.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
			
				printf("\n%d %d %d\n", p1.state, p3.state, p4.state);
				
				//It generates WriteMiss on the bus operation
				printf("\np2 state : INVALID. It generates WriteMiss to bus operation\n");
				
				//copy values from block memory --> p2 cache block
				for(int i = 0 ; i < 4; i++){
					p2._processor_cache_block[i] = b._memory_block[i];
				}
				
				//write the _memory_location_value in the location of cache Memory
					p2._processor_cache_block[location] = _memory_location_value;
					

				p2.state = 1; //changed the state to MODIFIED;
				printf("p2 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p2._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np2 state :MODIFIED\n");
				
			}
			
			else if(p2.state = 1 && p2._processor_cache_block[location] != 0){   //status is MODIFIED, not need to copy values from memory block, replace the user_value to cache block
			
				//checking other processors states weather it is in MODIFIED STATE
				if(p1.state == 0 || p1.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				p1.state = -1;
				}
				if(p3.state == 0 || p3.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p4.state == 0 || p4.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
				
				//p2 writes specific location value			
				p2._processor_cache_block[location] = _memory_location_value;
				

				p2.state = 1; //changed the state to MODIFIED;
				printf("p2 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p2._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np2 state :MODIFIED\n");
			
				
				
			}
			if(p1.state == -1 ) printf("p1 state : INVALID\n");
			else if(p1.state == 0) printf("p1 state : SHARED\n");
			else if (p1.state == 1) printf("p1 state : MODIFIED\n");
			
			if(p3.state == -1 ) printf("p3 state : INVALID\n");
			else if(p3.state == 0) printf("p3 state : SHARED\n");
			else if (p3.state == 1) printf("p3 state : MODIFIED\n");
				
			if(p4.state == -1 ) printf("p4 state : INVALID\n");
			else if(p4.state == 0) printf("p4 state : SHARED\n");
			else if (p4.state == 1) printf("p4 state : MODIFIED\n"); 
			break;
			
		case 3:
			if(p3.state == -1 && p3._processor_cache_block[location] == 0){ //status INVALID and cache memory location is zero
				
				//checking other processors states weather it is in MODIFIED STATE
				if(p2.state == 0 || p2.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p2.state = -1;
				}
				if(p1.state == 0 || p1.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				p1.state = -1;
				}
				if(p4.state == 0 || p4.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
			
				
				//It generates WriteMiss on the bus operation
				printf("\np3 state : INVALID. It generates WriteMiss to bus operation\n");
				
				//copy values from block memory --> p3 cache block
				for(int i = 0 ; i < 4; i++){
					p3._processor_cache_block[i] = b._memory_block[i];
				}
				
				//write the _memory_location_value in the location of cache Memory
					p3._processor_cache_block[location] = _memory_location_value;
					
					
				p3.state = 1; //changed the state to MODIFIED;
				printf("p3 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p3._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np3 state :MODIFIED\n");
				
			}
			
			else if(p3.state = 1 && p3._processor_cache_block[location] != 0){   //status is MODIFIED, not need to copy values from memory block, replace the user_value to cache block
			
				//checking other processors states weather it is in MODIFIED STATE
				if(p1.state == 0 || p1.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				p1.state = -1;

				}
				if(p2.state == 0 || p2.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p2.state = -1;
				}
				if(p4.state == 0 || p4.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p4._processor_cache_block[i];
				p4.state = -1;
				}
				
				//p3 writes specific location value			
				p3._processor_cache_block[location] = _memory_location_value;
				

				p3.state = 1; //changed the state to MODIFIED;
				printf("p3 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p3._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np3 state :MODIFIED\n");
			
				
				
			}
			if(p2.state == -1 ) printf("p2 state : INVALID\n");
			else if(p2.state == 0) printf("p2 state : SHARED\n");
			else if (p2.state == 1) printf("p2 state : MODIFIED\n");
			
			if(p1.state == -1 ) printf("p1 state : INVALID\n");
			else if(p1.state == 0) printf("p1 state : SHARED\n");
			else if (p1.state == 1) printf("p1 state : MODIFIED\n");
				
			if(p4.state == -1 ) printf("p4 state : INVALID\n");
			else if(p4.state == 0) printf("p4 state : SHARED\n");
			else if (p4.state == 1) printf("p4 state : MODIFIED\n"); 
			break;
		case 4:
			if(p4.state == -1 && p4._processor_cache_block[location] == 0){ //status INVALID and cache memory location is zero
				
				//checking other processors states weather it is in MODIFIED STATE
				if(p1.state == 0 || p1.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				p1.state = -1;
				}
				if(p3.state == 0 || p3.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p2.state == 0 || p2.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p2.state = -1;
				}
			
				
				//It generates WriteMiss on the bus operation
				printf("\np4 state : INVALID. It generates WriteMiss to bus operation\n");
				
				//copy values from block memory --> p4 cache block
				for(int i = 0 ; i < 4; i++){
					p4._processor_cache_block[i] = b._memory_block[i];
				}
				
				//write the _memory_location_value in the location of cache Memory
					p4._processor_cache_block[location] = _memory_location_value;
									
				p4.state = 1; //changed the state to MODIFIED;
				printf("p4 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p4._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np4 state :MODIFIED\n");
				
			}
			
			else if(p4.state = 1 && p4._processor_cache_block[location] != 0){   //status is MODIFIED, not need to copy values from memory block, replace the user_value to cache block
			
				//checking other processors states weather it is in MODIFIED STATE
				if(p1.state == 0 || p1.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p1._processor_cache_block[i];
				p1.state = -1;
				}
				if(p3.state == 0 || p3.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p3._processor_cache_block[i];
				p3.state = -1;
				}
				if(p2.state == 0 || p2.state == 1){
				for(int i = 0 ; i < 4; i++) b._memory_block[i] = p2._processor_cache_block[i];
				p4.state = -1;
				}
				
				//p4 writes specific location value			 
				p4._processor_cache_block[location] = _memory_location_value;
				
				p4.state = 1; //changed the state to MODIFIED;
				printf("p4 processor :");
				for(int i = 0 ; i < 4 ; i++) printf("%d,", p4._processor_cache_block[i]);
				printf("\n");
				printf("Memory block :");
				for(int i = 0 ; i < 4; i++) printf("%d,", b._memory_block[i]);
				printf("\n\np4 state :MODIFIED\n");
			
								
			}
			
			if(p2.state == -1 ) printf("p2 state : INVALID\n");
			else if(p2.state == 0) printf("p2 state : SHARED\n");
			else if (p2.state == 1) printf("p2 state : MODIFIED\n");
			
			if(p3.state == -1 ) printf("p3 state : INVALID\n");
			else if(p3.state == 0) printf("p3 state : SHARED\n");
			else if (p3.state == 1) printf("p3 state : MODIFIED\n");
				
			if(p1.state == -1 ) printf("p1 state : INVALID\n");
			else if(p1.state == 0) printf("p1 state : SHARED\n");
			else if (p1.state == 1) printf("p1 state : MODIFIED\n"); 
			
			break;
			
				
	}
}
int main(int argc, char** argv) {
	
	
	int processor_id;
	int choice;
	int user_value;
	char location_new;
	
	//input block user
	printf("Initalize the values of locations in Block Memory:");
	for(int i = 0; i < 4 ; i++)scanf("%d", &b._memory_block[i]);
	
	do{
		
	
	//input of the processors by user
	printf("\nEnter the processor : ");
	scanf("%d", &processor_id);
	
	int operation;
	//input operation by user
	printf("Perform an operation : \n");
	printf("1.Read from cache block\n2.Write to cache Block\n");
	printf("Enter your Operation:");
	scanf("%d", &operation);
	

	//input location by the user
	printf("Enter location in the cache Memory: ");
	cin >> location_new;
	
	int location_index;
	//map the location with the indexes of block memory
	switch(location_new){
		case 'A':
			location_index  = 0;
			break;
		case 'B':
			location_index = 1;
			break;
		case 'C':
			location_index = 2;
			break;
		case 'D':
			location_index = 3;
			break;
	}
	
	switch(operation){
		case 1:
			readProcessor(processor_id, location_index);
			break;
		case 2:
			printf("\nEnter the value to insert in the location cache Memory:");
			cin >> user_value;
			writeProcessor(processor_id, location_index, user_value);
	}
	
	
	printf("\n1.Continue the process\n2.exit\n");
	printf("Enter your Option:");
	
	scanf("%d", &choice);
	
}while(choice != 2);
			
	
	 	
	return 0;
}
